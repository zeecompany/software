"""Advanced built-in PDF Studio for AURCO documents."""
from __future__ import annotations

import shutil
from pathlib import Path

from PIL.ImageQt import ImageQt
from PySide6.QtCore import QEvent, QPoint, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QDragEnterEvent, QDropEvent, QIcon, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QApplication, QColorDialog, QDialog,
                               QFileDialog, QFormLayout, QFrame, QGroupBox, QHBoxLayout,
                               QInputDialog, QLabel, QLineEdit, QListWidget, QListWidgetItem,
                               QMessageBox, QPlainTextEdit, QPushButton, QScrollArea,
                               QSlider, QSpinBox, QSplitter, QTabWidget, QTableWidget,
                               QTableWidgetItem, QVBoxLayout, QWidget, QCheckBox,
                               QComboBox)
try:
    from PySide6.QtPrintSupport import QPrinterInfo
except Exception:  # noqa: BLE001
    QPrinterInfo = None

from ..core import documents as D
from ..core import pdf_tools as PT
from ..core.database import get_db
from . import widgets as W

PDF_SUPPORTED = True

_VIEWER = None


class ClickableLabel(QLabel):
    pointPicked = Signal(float, float)

    def mousePressEvent(self, ev):
        if self.pixmap() and self.width() and self.height():
            x = max(0.0, min(100.0, ev.position().x() / max(1.0, self.width()) * 100.0))
            y = max(0.0, min(100.0, ev.position().y() / max(1.0, self.height()) * 100.0))
            self.pointPicked.emit(x, y)
        super().mousePressEvent(ev)


class PdfViewerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AURCO PDF Studio")
        self.resize(1440, 900)
        self.setAcceptDrops(True)
        self.source_path: Path | None = None
        self.work_path: Path | None = None
        self.page_index = 0
        self.page_total = 0
        self.zoom_pct = 100
        self.view_rotation = 0
        self.source_mtime = 0.0
        self.restored = False
        self.text_pages: list[str] = []
        self.page_metrics: list[tuple[float, float]] = []
        self.render_display_scale = 1.0
        self.render_engine_scale = 1.0
        self.bound_doc: dict | None = None
        self.bound_db = None
        self.sig_dragging = False
        self.sig_drag_offset = QPoint(0, 0)
        self.pan_dragging = False
        self.pan_last = QPoint(0, 0)
        self.ctrl_zoom_dragging = False
        self.ctrl_zoom_start = QPoint(0, 0)
        self.ctrl_zoom_base = 100

        root = QVBoxLayout(self)
        root.setContentsMargins(10, 10, 10, 10)
        root.setSpacing(8)

        hero = QFrame()
        hero.setStyleSheet(
            "QFrame{background:qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #0b3d6b,stop:1 #165d99);"
            "border-radius:16px;} QLabel{color:white;}"
        )
        hv = QVBoxLayout(hero)
        hv.setContentsMargins(16, 14, 16, 14)
        self.caption = QLabel("PDF Studio")
        self.caption.setStyleSheet("font-size:20px;font-weight:700;")
        hv.addWidget(self.caption)
        self.sub = QLabel("View, search, annotate, protect, convert, print and organize PDFs from inside AURCO.")
        self.sub.setWordWrap(True)
        hv.addWidget(self.sub)
        root.addWidget(hero)

        toolbar = QHBoxLayout()
        for text, slot, tip in (
                ("📂 Open PDF", self.pick_file, "Open any PDF file"),
                ("💾 Save", self.save_current, "Save the working copy back to the source file"),
                ("📥 Save Copy", self.save_as, "Save the working copy to a new PDF file"),
                ("⧉ Duplicate", self.duplicate_file, "Create a duplicate PDF file"),
                ("✏ Rename", self.rename_file, "Rename the current PDF"),
                ("↶ Undo", self.undo, "Undo the last PDF change"),
                ("↷ Redo", self.redo, "Redo the last undone change"),
                ("📂 Open Folder", self.open_folder, "Open the file location")):
            toolbar.addWidget(W.button(text, "Primary" if text.startswith("📂 Open") else "", slot, tip))
        toolbar.addStretch(1)
        root.addLayout(toolbar)

        nav = QHBoxLayout()
        self.btn_prev = W.button("◀ Prev", slot=lambda: self.goto_page(self.page_index - 1))
        self.btn_next = W.button("Next ▶", slot=lambda: self.goto_page(self.page_index + 1))
        self.spin_page = QSpinBox()
        self.spin_page.setRange(1, 1)
        self.spin_page.valueChanged.connect(lambda v: self.goto_page(v - 1, sync=False))
        self.lbl_pages = QLabel("/ 0")
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search text inside this PDF...")
        self.search.returnPressed.connect(self.run_search)
        self.fit_mode = QComboBox()
        self.fit_mode.addItems(["Fit Page", "Fit Width", "Actual Size"])
        self.fit_mode.currentTextChanged.connect(self._schedule_render)
        self.zoom_slider = QSlider(Qt.Horizontal)
        self.zoom_slider.setRange(50, 250)
        self.zoom_slider.setPageStep(10)
        self.zoom_slider.setValue(100)
        self.zoom_slider.valueChanged.connect(self.set_zoom)
        self.lbl_zoom = QLabel("100%")
        nav.addWidget(self.btn_prev)
        nav.addWidget(self.btn_next)
        nav.addWidget(QLabel("Page"))
        nav.addWidget(self.spin_page)
        nav.addWidget(self.lbl_pages)
        nav.addSpacing(12)
        nav.addWidget(W.button("⟲ View Left", slot=lambda: self.rotate_view(-90)))
        nav.addWidget(W.button("⟳ View Right", slot=lambda: self.rotate_view(90)))
        nav.addSpacing(12)
        nav.addWidget(QLabel("Search"))
        nav.addWidget(self.search, 1)
        nav.addWidget(W.button("Find", slot=self.run_search))
        nav.addSpacing(12)
        nav.addWidget(QLabel("Preview"))
        nav.addWidget(self.fit_mode)
        nav.addWidget(W.button("－", slot=lambda: self.zoom_slider.setValue(max(self.zoom_slider.minimum(), self.zoom_slider.value() - 10))))
        nav.addWidget(self.zoom_slider)
        nav.addWidget(W.button("＋", slot=lambda: self.zoom_slider.setValue(min(self.zoom_slider.maximum(), self.zoom_slider.value() + 10))))
        nav.addWidget(self.lbl_zoom)
        nav.addWidget(W.button("100%", slot=self.reset_zoom))
        root.addLayout(nav)

        split = QSplitter()
        root.addWidget(split, 1)

        left = QTabWidget()
        split.addWidget(left)

        self.recent = QListWidget()
        self.recent.itemDoubleClicked.connect(self._open_recent)
        left.addTab(self.recent, "Recent Files")

        self.thumbs = QListWidget()
        self.thumbs.setViewMode(QListWidget.IconMode)
        self.thumbs.setResizeMode(QListWidget.Adjust)
        self.thumbs.setIconSize(QPixmap(110, 150).size())
        self.thumbs.setMovement(QListWidget.Static)
        self.thumbs.itemClicked.connect(self._open_thumbnail)
        left.addTab(self.thumbs, "Thumbnails")

        self.search_hits = QListWidget()
        self.search_hits.itemClicked.connect(self._open_search_hit)
        left.addTab(self.search_hits, "Search Hits")

        middle = QWidget()
        mv = QVBoxLayout(middle)
        mv.setContentsMargins(0, 0, 0, 0)
        mv.setSpacing(6)
        self.pick_note = QLabel("Tip: drag and drop a PDF here, or open one from Documents / Reports / Library. Use Ctrl + mouse wheel or Ctrl + drag up/down to zoom, and middle-drag to pan around the page.")
        self.pick_note.setWordWrap(True)
        self.pick_note.setStyleSheet("color:#5f6368")
        mv.addWidget(self.pick_note)
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setAlignment(Qt.AlignCenter)
        self.scroll.setStyleSheet("QScrollArea{background:#dfe6ee;border:1px solid #c9d3df;border-radius:14px;}")
        self.page_view = ClickableLabel()
        self.page_view.setAlignment(Qt.AlignCenter)
        self.page_view.setMinimumSize(420, 520)
        self.page_view.setStyleSheet("background:white;border:1px solid #cbd5e1;border-radius:14px;")
        self.page_view.setText("Open a PDF to start.")
        self.page_view.setMouseTracking(True)
        self.page_view.setCursor(Qt.OpenHandCursor)
        self.page_view.installEventFilter(self)
        self.page_view.pointPicked.connect(self.capture_point)
        self.sig_overlay = QLabel(self.page_view)
        self.sig_overlay.setVisible(False)
        self.sig_overlay.setStyleSheet("background:rgba(11,61,107,0.08);border:2px dashed #0b3d6b;border-radius:8px;")
        self.sig_overlay.installEventFilter(self)
        self.scroll.setWidget(self.page_view)
        self.scroll.horizontalScrollBar().setSingleStep(28)
        self.scroll.verticalScrollBar().setSingleStep(28)
        mv.addWidget(self.scroll, 1)
        self.page_meta = QLabel()
        self.page_meta.setWordWrap(True)
        self.page_meta.setStyleSheet("color:#5f6368;padding:2px 4px;")
        mv.addWidget(self.page_meta)
        split.addWidget(middle)

        right = QTabWidget()
        split.addWidget(right)
        split.setSizes([250, 760, 380])

        # annotate ------------------------------------------------------------
        annot = QWidget()
        av = QVBoxLayout(annot)
        g = QGroupBox("Annotation / signature")
        f = QFormLayout(g)
        self.a_pages = QLineEdit("1")
        self.a_pages.setPlaceholderText("Examples: 1 or 1,3-5")
        self.a_kind = QComboBox()
        self.a_kind.addItems(["Text", "Note", "Stamp", "Highlight", "Underline", "Line", "Box", "Signature"])
        self.a_text = QPlainTextEdit()
        self.a_text.setPlaceholderText("Type the text, note, stamp label or signature caption...")
        self.a_text.setMaximumHeight(90)
        self.a_x = QSpinBox(); self.a_x.setRange(0, 100); self.a_x.setValue(8)
        self.a_y = QSpinBox(); self.a_y.setRange(0, 100); self.a_y.setValue(8)
        self.a_w = QSpinBox(); self.a_w.setRange(1, 100); self.a_w.setValue(30)
        self.a_h = QSpinBox(); self.a_h.setRange(1, 100); self.a_h.setValue(8)
        xy = QHBoxLayout(); xy.addWidget(self.a_x); xy.addWidget(self.a_y); xy.addWidget(self.a_w); xy.addWidget(self.a_h)
        xyw = QWidget(); xyw.setLayout(xy)
        self.a_color = QLineEdit("#ffbf00")
        cbar = QHBoxLayout(); cbar.addWidget(self.a_color, 1); cbar.addWidget(W.button("Pick", slot=self.pick_color))
        cw = QWidget(); cw.setLayout(cbar)
        self.a_image = QLineEdit()
        ibar = QHBoxLayout(); ibar.addWidget(self.a_image, 1)
        ibar.addWidget(W.button("Browse", slot=self.pick_signature_image))
        ibar.addWidget(W.button("Paste", slot=self.paste_signature_image))
        ibar.addWidget(W.button("Reset position", slot=self.reset_signature_position))
        iw = QWidget(); iw.setLayout(ibar)
        f.addRow("Pages", self.a_pages)
        f.addRow("Tool", self.a_kind)
        f.addRow("Text / caption", self.a_text)
        f.addRow("X % / Y % / W % / H %", xyw)
        f.addRow("Colour", cw)
        f.addRow("Signature image", iw)
        av.addWidget(g)
        ag = QHBoxLayout()
        ag.addWidget(W.button("Use current page", slot=lambda: self.a_pages.setText(str(self.page_index + 1))))
        ag.addWidget(W.button("Apply to PDF", "Accent", self.apply_annotation))
        ag.addWidget(W.button("Save Signed Copy", slot=self.save_signed_copy))
        av.addLayout(ag)
        hint = QLabel("Tip: click anywhere on the PDF preview to capture X/Y placement. For signatures, paste or browse the signature image, then drag the on-page preview to the exact position you want.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#5f6368")
        av.addWidget(hint)
        self.a_kind.currentTextChanged.connect(self._refresh_signature_overlay)
        self.a_image.textChanged.connect(self._refresh_signature_overlay)
        for _sp in (self.a_x, self.a_y, self.a_w, self.a_h):
            _sp.valueChanged.connect(self._refresh_signature_overlay)
        av.addStretch(1)
        right.addTab(annot, "Annotate")

        # organize ------------------------------------------------------------
        org = QWidget()
        ov = QVBoxLayout(org)
        self.page_table = QTableWidget(0, 3)
        self.page_table.setHorizontalHeaderLabels(["Page", "Size", "Actions"])
        self.page_table.verticalHeader().setVisible(False)
        self.page_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.page_table.setSelectionMode(QAbstractItemView.ExtendedSelection)
        ov.addWidget(self.page_table, 1)
        row1 = QHBoxLayout()
        row1.addWidget(W.button("▲ Move Up", slot=lambda: self.move_selected_pages(-1)))
        row1.addWidget(W.button("▼ Move Down", slot=lambda: self.move_selected_pages(1)))
        row1.addWidget(W.button("💾 Apply Order", "Accent", self.apply_page_order))
        ov.addLayout(row1)
        row2 = QHBoxLayout()
        row2.addWidget(W.button("⧉ Duplicate Pages", slot=self.duplicate_selected_pages))
        row2.addWidget(W.button("🗑 Delete Pages", slot=self.delete_selected_pages))
        row2.addWidget(W.button("📤 Extract Pages", slot=self.extract_selected_pages))
        ov.addLayout(row2)
        row3 = QHBoxLayout()
        row3.addWidget(W.button("⟲ Rotate Left", slot=lambda: self.rotate_selected_pages(-90)))
        row3.addWidget(W.button("⟳ Rotate Right", slot=lambda: self.rotate_selected_pages(90)))
        row3.addWidget(W.button("➕ Merge Another PDF", slot=self.merge_pdf))
        row3.addWidget(W.button("✂ Split by Range", slot=self.split_pdf))
        ov.addLayout(row3)
        right.addTab(org, "Organize")

        # convert -------------------------------------------------------------
        conv = QWidget()
        cv = QVBoxLayout(conv)
        cv.addWidget(QLabel("Export / convert the current working PDF into other useful formats."))
        for text, slot in (("Export to PNG pages", lambda: self.export_images("png")),
                           ("Export to JPG pages", lambda: self.export_images("jpg")),
                           ("Convert to Word (.docx)", self.export_docx),
                           ("Convert to Excel (.xlsx)", self.export_xlsx),
                           ("Export text (.txt)", self.export_txt),
                           ("Export HTML", self.export_html)):
            cv.addWidget(W.button(text, slot=slot))
        cv.addStretch(1)
        right.addTab(conv, "Convert")

        # print ---------------------------------------------------------------
        prn = QWidget()
        pv = QVBoxLayout(prn)
        pg = QGroupBox("Print options")
        pf = QFormLayout(pg)
        self.p_range = QLineEdit("")
        self.p_range.setPlaceholderText("Blank = all pages, or e.g. 1-3,5")
        self.p_orientation = QComboBox(); self.p_orientation.addItems(["Original", "Portrait", "Landscape"])
        self.p_copies = QSpinBox(); self.p_copies.setRange(1, 99); self.p_copies.setValue(1)
        self.p_printer = W.combo([], editable=True)
        self.p_printer.setMinimumWidth(280)
        pbar = QHBoxLayout()
        pbar.addWidget(self.p_printer, 1)
        pbar.addWidget(W.button("Refresh", slot=self.reload_printers))
        pbar.addWidget(W.button("Save as default", slot=self.save_default_printer))
        pw = QWidget(); pw.setLayout(pbar)
        pf.addRow("Page range", self.p_range)
        pf.addRow("Orientation", self.p_orientation)
        pf.addRow("Copies", self.p_copies)
        pf.addRow("Printer", pw)
        pv.addWidget(pg)
        prow = QHBoxLayout()
        prow.addWidget(W.button("Preview Print Job", slot=self.preview_print_job))
        prow.addWidget(W.button("Print", "Accent", self.print_with_options))
        pv.addLayout(prow)
        pv.addStretch(1)
        right.addTab(prn, "Print")

        # security ------------------------------------------------------------
        sec = QWidget()
        sv = QVBoxLayout(sec)
        sg = QGroupBox("Password protection / encryption")
        sf = QFormLayout(sg)
        self.sec_user = QLineEdit(); self.sec_user.setEchoMode(QLineEdit.Password)
        self.sec_owner = QLineEdit(); self.sec_owner.setEchoMode(QLineEdit.Password)
        self.sec_print = QCheckBox("Allow printing"); self.sec_print.setChecked(True)
        self.sec_copy = QCheckBox("Allow copying text / graphics"); self.sec_copy.setChecked(True)
        self.sec_modify = QCheckBox("Allow editing / assembly"); self.sec_modify.setChecked(False)
        sf.addRow("Open password", self.sec_user)
        sf.addRow("Owner password", self.sec_owner)
        sf.addRow(self.sec_print)
        sf.addRow(self.sec_copy)
        sf.addRow(self.sec_modify)
        sv.addWidget(sg)
        sv.addWidget(W.button("Save Protected Copy", "Accent", self.protect_copy))
        sv.addStretch(1)
        right.addTab(sec, "Security")

        # share ---------------------------------------------------------------
        shr = QWidget()
        shv = QVBoxLayout(shr)
        share = QGroupBox("Share current PDF")
        sfm = QFormLayout(share)
        self.mail_to = QLineEdit(); self.mail_to.setPlaceholderText("name@example.com")
        self.wa_to = QLineEdit(); self.wa_to.setPlaceholderText("9665XXXXXXXX")
        sfm.addRow("Email to", self.mail_to)
        sfm.addRow("WhatsApp number", self.wa_to)
        shv.addWidget(share)
        srow1 = QHBoxLayout()
        srow1.addWidget(W.button("✉ Email PDF", slot=self.share_email))
        srow1.addWidget(W.button("🟢 WhatsApp PDF", slot=self.share_whatsapp))
        srow1.addWidget(W.button("🔗 Copy file link", slot=self.copy_file_link))
        shv.addLayout(srow1)
        srow2 = QHBoxLayout()
        srow2.addWidget(W.button("📋 Copy path", slot=self.copy_path))
        srow2.addWidget(W.button("📂 Open folder", slot=self.open_folder))
        shv.addLayout(srow2)
        shv.addStretch(1)
        right.addTab(shr, "Share")

        self.status = QLabel("Ready.")
        self.status.setStyleSheet("color:#5f6368;padding:4px")
        root.addWidget(self.status)

        self.timer = QTimer(self)
        self.timer.setInterval(2500)
        self.timer.timeout.connect(self._check_source_update)
        self.timer.start()
        self.resize_timer = QTimer(self)
        self.resize_timer.setSingleShot(True)
        self.resize_timer.setInterval(120)
        self.resize_timer.timeout.connect(self._rerender_after_resize)
        self.scroll.viewport().installEventFilter(self)
        self.reload_printers()
        self.reload_recent()
        self._update_actions()

    # ----------------------------------------------------------------- events
    def dragEnterEvent(self, ev: QDragEnterEvent):
        if ev.mimeData().hasUrls():
            for url in ev.mimeData().urls():
                if url.isLocalFile() and url.toLocalFile().lower().endswith(".pdf"):
                    ev.acceptProposedAction()
                    return
        ev.ignore()

    def dropEvent(self, ev: QDropEvent):
        for url in ev.mimeData().urls():
            if url.isLocalFile() and url.toLocalFile().lower().endswith(".pdf"):
                self.open_file(url.toLocalFile())
                ev.acceptProposedAction()
                return
        ev.ignore()

    def eventFilter(self, obj, ev):
        if obj is self.scroll.viewport() and ev.type() == QEvent.Resize and self._current_pdf():
            self._schedule_render()
        elif obj in (self.page_view, self.scroll.viewport()):
            if ev.type() == QEvent.Wheel and self._current_pdf() and (ev.modifiers() & Qt.ControlModifier):
                step = 10 if ev.angleDelta().y() > 0 else -10
                self.zoom_slider.setValue(max(self.zoom_slider.minimum(),
                                              min(self.zoom_slider.maximum(),
                                                  self.zoom_slider.value() + step)))
                return True
            if ev.type() == QEvent.MouseButtonPress and self._current_pdf():
                if ev.button() == Qt.MiddleButton:
                    self.pan_dragging = True
                    self.pan_last = ev.globalPosition().toPoint()
                    self.page_view.setCursor(Qt.ClosedHandCursor)
                    return True
                if ev.button() == Qt.LeftButton and (ev.modifiers() & Qt.ControlModifier):
                    self.ctrl_zoom_dragging = True
                    self.ctrl_zoom_start = ev.globalPosition().toPoint()
                    self.ctrl_zoom_base = self.zoom_slider.value()
                    self._set_status("Ctrl+drag zoom is active.")
                    return True
            if ev.type() == QEvent.MouseMove:
                if self.pan_dragging:
                    pos = ev.globalPosition().toPoint()
                    delta = pos - self.pan_last
                    self.pan_last = pos
                    self.scroll.horizontalScrollBar().setValue(
                        self.scroll.horizontalScrollBar().value() - delta.x())
                    self.scroll.verticalScrollBar().setValue(
                        self.scroll.verticalScrollBar().value() - delta.y())
                    return True
                if self.ctrl_zoom_dragging:
                    dy = self.ctrl_zoom_start.y() - ev.globalPosition().toPoint().y()
                    val = self.ctrl_zoom_base + int(round(dy / 3.0))
                    self.zoom_slider.setValue(max(self.zoom_slider.minimum(),
                                                  min(self.zoom_slider.maximum(), val)))
                    return True
            if ev.type() == QEvent.MouseButtonRelease:
                if ev.button() == Qt.MiddleButton and self.pan_dragging:
                    self.pan_dragging = False
                    self.page_view.setCursor(Qt.OpenHandCursor if self._current_pdf() else Qt.ArrowCursor)
                    return True
                if ev.button() == Qt.LeftButton and self.ctrl_zoom_dragging:
                    self.ctrl_zoom_dragging = False
                    self._set_status(f"Zoom set to {self.zoom_slider.value()}%.")
                    return True
        elif obj is self.sig_overlay:
            if ev.type() == QEvent.MouseButtonPress and ev.button() == Qt.LeftButton:
                self.sig_dragging = True
                self.sig_drag_offset = ev.position().toPoint()
                return True
            if ev.type() == QEvent.MouseMove and self.sig_dragging:
                pos = self.sig_overlay.pos() + ev.position().toPoint() - self.sig_drag_offset
                self._move_signature_overlay(pos)
                return True
            if ev.type() == QEvent.MouseButtonRelease and self.sig_dragging:
                self.sig_dragging = False
                self._set_status("Signature position updated from the preview.")
                return True
        return super().eventFilter(obj, ev)

    # ---------------------------------------------------------------- helpers
    def _db(self):
        try:
            return get_db()
        except Exception:
            return None

    def _bind_document(self, path: Path) -> Path:
        self.bound_db = self._db()
        self.bound_doc = D.document_binding_for_path(self.bound_db, path)
        if self.bound_doc and self.bound_db:
            official = D.resolve_document_pdf_path(self.bound_db, self.bound_doc) or path
            return official.resolve()
        return path.resolve()

    def _bound_label(self) -> str:
        if not self.bound_doc:
            return ""
        return f"{self.bound_doc.get('doc_type','DOC')} {self.bound_doc.get('doc_no','')}"

    def _set_status(self, text: str):
        self.status.setText(text)

    def _current_pdf(self) -> Path | None:
        return self.work_path if self.work_path and self.work_path.exists() else None

    def _share_pdf(self) -> Path | None:
        cur = self._current_pdf()
        if not cur or not self.source_path:
            return None
        if self.is_dirty():
            out = PT.default_export_path(self.source_path, ".shared.pdf")
            shutil.copy2(cur, out)
            return out
        return self.source_path

    def is_dirty(self) -> bool:
        if not self.source_path:
            return False
        sp = PT.session_paths(self.source_path)
        if sp["meta"].exists():
            try:
                import json
                meta = json.loads(sp["meta"].read_text(encoding="utf-8"))
                return bool(meta.get("dirty"))
            except Exception:
                return False
        return False

    def _ensure_open(self) -> bool:
        if not self.source_path or not self.work_path or not self.work_path.exists():
            W.error_box(self, "Open a PDF first.")
            return False
        return True

    def _selected_rows(self) -> list[int]:
        return sorted({i.row() for i in self.page_table.selectedIndexes()})

    def _selected_pages(self) -> list[int]:
        rows = self._selected_rows()
        if not rows:
            rows = [self.page_index]
        return [int(self.page_table.item(r, 0).data(Qt.UserRole)) for r in rows]

    def _picked_range(self) -> list[int]:
        if not self._ensure_open():
            return []
        return PT.parse_page_range(self.a_pages.text(), self.page_total)

    def _apply_workspace(self, maker, msg: str):
        if not self._ensure_open() or not self.source_path:
            return
        PT.replace_workspace(self.source_path, maker)
        self.reload_document(keep_page=True)
        self._set_status(msg + " Auto-saved to the working copy.")

    def _orientation_rotate(self, page_list: list[int]) -> dict[int, int]:
        if not self._ensure_open():
            return {}
        mode = self.p_orientation.currentText()
        if mode == "Original":
            return {}
        sizes = PT.page_sizes(self._current_pdf())
        out = {}
        for i in page_list:
            w, h = sizes[i]
            if mode == "Landscape" and h > w:
                out[i] = 90
            elif mode == "Portrait" and w > h:
                out[i] = 90
        return out

    def _make_subset(self) -> Path | None:
        if not self._ensure_open() or not self.source_path:
            return None
        pdf = self._current_pdf()
        idx = PT.parse_page_range(self.p_range.text(), self.page_total)
        out = PT.default_export_path(self.source_path, ".print-preview.pdf")
        rot = self._orientation_rotate(idx)
        PT._write_pages(PT._reader(pdf), idx, out, rot)
        return out

    def _schedule_render(self, *_):
        if self._current_pdf():
            self.resize_timer.start()

    def _rerender_after_resize(self):
        if self._current_pdf():
            self.render_current_page()

    def reset_zoom(self):
        self.zoom_slider.setValue(100)
        self.fit_mode.setCurrentText("Actual Size")

    def _current_page_dims(self) -> tuple[float, float]:
        if not self.page_metrics or not (0 <= self.page_index < len(self.page_metrics)):
            return 595.0, 842.0
        w, h = self.page_metrics[self.page_index]
        if self.view_rotation % 180:
            return h, w
        return w, h

    def _page_label(self, width_pt: float, height_pt: float) -> str:
        mm_w = width_pt * 25.4 / 72.0
        mm_h = height_pt * 25.4 / 72.0
        long_edge = max(mm_w, mm_h)
        short_edge = min(mm_w, mm_h)
        if abs(short_edge - 210) < 8 and abs(long_edge - 297) < 8:
            return "A4"
        if abs(short_edge - 216) < 8 and abs(long_edge - 279) < 8:
            return "Letter"
        if abs(short_edge - 148) < 8 and abs(long_edge - 210) < 8:
            return "A5"
        return f"{round(mm_w)} × {round(mm_h)} mm"

    def _preview_scales(self) -> tuple[float, float]:
        width_pt, height_pt = self._current_page_dims()
        vp = self.scroll.viewport().size()
        avail_w = max(220, vp.width() - 34)
        avail_h = max(260, vp.height() - 34)
        fit_page = min(avail_w / max(1.0, width_pt), avail_h / max(1.0, height_pt))
        fit_width = avail_w / max(1.0, width_pt)
        actual = 96.0 / 72.0
        mode = self.fit_mode.currentText()
        base = fit_page if mode == "Fit Page" else fit_width if mode == "Fit Width" else actual
        display_scale = max(0.25, base * (self.zoom_pct / 100.0))
        quality_boost = 1.6 if mode == "Actual Size" else 2.4
        if self.a_kind.currentText() in ("Signature", "Stamp"):
            quality_boost = max(quality_boost, 2.8)
        engine_scale = max(0.8, min(8.0, display_scale * quality_boost))
        return display_scale, engine_scale

    def _selected_printer_name(self) -> str:
        name = (self.p_printer.currentText() or "").strip()
        return "" if name == "(Use system default)" else name

    def reload_printers(self):
        current = self._selected_printer_name() if hasattr(self, "p_printer") else ""
        names: list[str] = []
        if QPrinterInfo is not None:
            try:
                names = [p.printerName().strip() for p in QPrinterInfo.availablePrinters() if p.printerName().strip()]
            except Exception:
                names = []
            if not names:
                try:
                    default_name = (QPrinterInfo.defaultPrinter().printerName() or "").strip()
                    if default_name:
                        names = [default_name]
                except Exception:
                    pass
        db = self._db()
        saved = (db.get_setting("printer_name", "") if db else "") or ""
        for extra in (saved, current):
            extra = (extra or "").strip()
            if extra and extra not in names:
                names.append(extra)
        self.p_printer.blockSignals(True)
        self.p_printer.clear()
        self.p_printer.addItem("(Use system default)")
        for name in names:
            self.p_printer.addItem(name)
        target = current or saved
        if target:
            idx = self.p_printer.findText(target)
            if idx >= 0:
                self.p_printer.setCurrentIndex(idx)
            else:
                self.p_printer.setCurrentText(target)
        else:
            self.p_printer.setCurrentIndex(0)
        self.p_printer.blockSignals(False)

    def save_default_printer(self):
        db = self._db()
        if not db:
            W.error_box(self, "Database is not available right now.")
            return
        printer = self._selected_printer_name()
        db.set_setting("printer_name", printer)
        self._set_status("Saved the selected printer as the PDF Studio default." if printer
                         else "PDF Studio will now use the system default printer.")

    def reset_signature_position(self):
        self.a_x.setValue(8)
        self.a_y.setValue(8)
        self.a_w.setValue(30)
        self.a_h.setValue(8)
        self._refresh_signature_overlay()

    def _signature_overlay_ready(self) -> bool:
        if self.a_kind.currentText() != "Signature":
            return False
        img_path = self.a_image.text().strip()
        if not img_path:
            return False
        pm = self.page_view.pixmap()
        return bool(pm and not pm.isNull() and Path(img_path).exists())

    def _refresh_signature_overlay(self, *_):
        if not self._signature_overlay_ready():
            self.sig_overlay.hide()
            return
        page_pm = self.page_view.pixmap()
        sig_pm = QPixmap(self.a_image.text().strip())
        if sig_pm.isNull() or page_pm is None or page_pm.isNull():
            self.sig_overlay.hide()
            return
        width = max(40, int(round(page_pm.width() * (self.a_w.value() / 100.0))))
        height = max(24, int(round(page_pm.height() * (self.a_h.value() / 100.0))))
        sig_scaled = sig_pm.scaled(width, height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.sig_overlay.setPixmap(sig_scaled)
        self.sig_overlay.resize(sig_scaled.size())
        self.sig_overlay.setToolTip("Drag this signature preview to place it visually on the page.")
        self._move_signature_overlay(QPoint(
            int(round(page_pm.width() * (self.a_x.value() / 100.0))),
            int(round(page_pm.height() * (self.a_y.value() / 100.0))),
        ), update_fields=False)
        self.sig_overlay.raise_()
        self.sig_overlay.show()

    def _move_signature_overlay(self, pos: QPoint, update_fields: bool = True):
        page_pm = self.page_view.pixmap()
        if page_pm is None or page_pm.isNull():
            self.sig_overlay.hide()
            return
        max_x = max(0, page_pm.width() - self.sig_overlay.width())
        max_y = max(0, page_pm.height() - self.sig_overlay.height())
        x = max(0, min(max_x, pos.x()))
        y = max(0, min(max_y, pos.y()))
        self.sig_overlay.move(x, y)
        if update_fields:
            self.a_x.blockSignals(True)
            self.a_y.blockSignals(True)
            self.a_x.setValue(round((x / max(1, page_pm.width())) * 100.0))
            self.a_y.setValue(round((y / max(1, page_pm.height())) * 100.0))
            self.a_x.blockSignals(False)
            self.a_y.blockSignals(False)

    # ---------------------------------------------------------------- opening
    def pick_file(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open PDF", str(Path.home()), "PDF Files (*.pdf)")
        if p:
            self.open_file(p)

    def open_file(self, path: str | Path, title: str = "") -> bool:
        p = Path(path)
        if not p.exists() or p.suffix.lower() != ".pdf":
            self._set_status("PDF file not found.")
            return False
        self.source_path = self._bind_document(p)
        self.work_path, self.restored = PT.load_workspace(self.source_path)
        self.source_mtime = self.source_path.stat().st_mtime
        self.caption.setText(title or self.source_path.name)
        sub = str(self.source_path)
        if self.bound_doc:
            sub += f"\nOfficial file bound to {self._bound_label()}"
        self.sub.setText(sub)
        self.page_index = 0
        self.view_rotation = 0
        self.fit_mode.setCurrentText("Fit Page")
        self.zoom_slider.setValue(100)
        self.reload_recent()
        self.reload_document(keep_page=False)
        self.show()
        self.raise_()
        self.activateWindow()
        self._set_status("Recovered the last auto-saved working copy." if self.restored
                         else (f"Opened the official {self._bound_label()} PDF in AURCO PDF Studio."
                               if self.bound_doc else "PDF opened in AURCO PDF Studio."))
        return True

    def reload_recent(self):
        self.recent.clear()
        for p in PT.recent_files():
            item = QListWidgetItem(Path(p).name)
            item.setToolTip(p)
            item.setData(Qt.UserRole, p)
            self.recent.addItem(item)

    def reload_document(self, keep_page: bool = True):
        if not self._ensure_open():
            return
        old = self.page_index
        self.page_total = PT.page_count(self.work_path)
        self.spin_page.blockSignals(True)
        self.spin_page.setRange(1, max(1, self.page_total))
        self.lbl_pages.setText(f"/ {self.page_total}")
        self.page_index = min(old if keep_page else 0, max(0, self.page_total - 1))
        self.spin_page.setValue(self.page_index + 1)
        self.spin_page.blockSignals(False)
        self.page_metrics = PT.page_sizes(self.work_path)
        self.text_pages = PT.extract_text(self.work_path)
        self._load_thumbnails()
        self._load_page_table()
        self.render_current_page()
        self._update_actions()

    def render_current_page(self):
        if not self._ensure_open():
            return
        width_pt, height_pt = self._current_page_dims()
        display_scale, engine_scale = self._preview_scales()
        self.render_display_scale = display_scale
        self.render_engine_scale = engine_scale
        img = PT.render_page(self.work_path, self.page_index, scale=engine_scale,
                             rotation=self.view_rotation)
        pm = QPixmap.fromImage(ImageQt(img))
        target_w = max(140, int(round(width_pt * display_scale)))
        target_h = max(180, int(round(height_pt * display_scale)))
        pm = pm.scaled(target_w, target_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.page_view.setPixmap(pm)
        self.page_view.resize(pm.size())
        orientation = "Landscape" if width_pt > height_pt else "Portrait"
        binding = f"  ·  {self._bound_label()}" if self.bound_doc else ""
        self.page_meta.setText(
            f"Page {self.page_index + 1}  ·  {self._page_label(width_pt, height_pt)}"
            f"  ·  {orientation}  ·  {self.fit_mode.currentText()}"
            f"  ·  View {self.zoom_pct}%  ·  Render {round(engine_scale * 100)}%"
            f"  ·  Rotation {self.view_rotation % 360}°{binding}"
        )
        self._highlight_page_selection()
        self._refresh_signature_overlay()

    def goto_page(self, page_index: int, sync: bool = True):
        if not self._ensure_open() or self.page_total < 1:
            return
        self.page_index = max(0, min(self.page_total - 1, int(page_index)))
        if sync:
            self.spin_page.blockSignals(True)
            self.spin_page.setValue(self.page_index + 1)
            self.spin_page.blockSignals(False)
        self.render_current_page()
        self._update_actions()

    def set_zoom(self, value: int):
        self.zoom_pct = int(value)
        self.lbl_zoom.setText(f"{self.zoom_pct}%")
        if self._current_pdf():
            self._schedule_render()

    def rotate_view(self, angle: int):
        self.view_rotation = (self.view_rotation + int(angle)) % 360
        if self._current_pdf():
            self._schedule_render()

    def _check_source_update(self):
        if not self.source_path or not self.source_path.exists():
            return
        cur = self.source_path.stat().st_mtime
        if cur != self.source_mtime:
            self.source_mtime = cur
            if not self.is_dirty():
                self.work_path, _ = PT.load_workspace(self.source_path)
                self.reload_document(keep_page=True)
                self._set_status("Source PDF refreshed from shared storage.")
            else:
                self._set_status("The source PDF changed on disk, but your local working copy has unsaved edits.")

    # ------------------------------------------------------------- side panels
    def _open_recent(self, item: QListWidgetItem):
        p = item.data(Qt.UserRole)
        if p:
            self.open_file(p)

    def _load_thumbnails(self):
        self.thumbs.clear()
        if not self._current_pdf():
            return
        limit = min(self.page_total, 80)
        for i in range(limit):
            try:
                thumb = PT.render_page(self.work_path, i, scale=0.30)
                pm = QPixmap.fromImage(ImageQt(thumb))
                icon = QIcon(pm)
            except Exception:
                icon = QIcon()
            item = QListWidgetItem(icon, f"{i + 1}")
            item.setData(Qt.UserRole, i)
            self.thumbs.addItem(item)
        if self.page_total > limit:
            item = QListWidgetItem(f"Only the first {limit} thumbnails are shown for speed.")
            item.setFlags(Qt.NoItemFlags)
            self.thumbs.addItem(item)

    def _open_thumbnail(self, item: QListWidgetItem):
        idx = item.data(Qt.UserRole)
        if idx is not None:
            self.goto_page(int(idx))

    def run_search(self):
        if not self._ensure_open():
            return
        self.search_hits.clear()
        hits = PT.search_text(self._current_pdf(), self.search.text().strip())
        for h in hits:
            item = QListWidgetItem(f"Page {h['page']} — {h['snippet']}")
            item.setData(Qt.UserRole, h["page"] - 1)
            self.search_hits.addItem(item)
        if hits:
            self.goto_page(hits[0]["page"] - 1)
            self._set_status(f"Found {len(hits)} text match(es).")
        else:
            self._set_status("No text matches were found in this PDF.")

    def _open_search_hit(self, item: QListWidgetItem):
        idx = item.data(Qt.UserRole)
        if idx is not None:
            self.goto_page(int(idx))

    def capture_point(self, x: float, y: float):
        self.a_x.setValue(round(x))
        self.a_y.setValue(round(y))
        self._set_status(f"Placement captured at X={round(x)}%, Y={round(y)}% on page {self.page_index + 1}.")

    def _load_page_table(self):
        self.page_table.setRowCount(0)
        if not self._current_pdf():
            return
        for r, meta in enumerate(PT.page_summary(self._current_pdf())):
            self.page_table.insertRow(r)
            it = QTableWidgetItem(str(meta["page"]))
            it.setData(Qt.UserRole, meta["page"] - 1)
            self.page_table.setItem(r, 0, it)
            self.page_table.setItem(r, 1, QTableWidgetItem(f"{meta['width']} × {meta['height']} pt"))
            self.page_table.setItem(r, 2, QTableWidgetItem("Organize / rotate / extract"))
        self.page_table.resizeColumnsToContents()

    def _highlight_page_selection(self):
        self.page_table.clearSelection()
        if 0 <= self.page_index < self.page_table.rowCount():
            self.page_table.selectRow(self.page_index)
        for i in range(self.thumbs.count()):
            item = self.thumbs.item(i)
            if item.flags() & Qt.ItemIsEnabled:
                item.setSelected(item.data(Qt.UserRole) == self.page_index)

    def _update_actions(self):
        self.btn_prev.setEnabled(self.page_index > 0)
        self.btn_next.setEnabled(self.page_index < max(0, self.page_total - 1))

    # ----------------------------------------------------------- file actions
    def save_current(self):
        if not self._ensure_open() or not self.source_path:
            return
        saved = PT.commit_workspace(self.source_path)
        self.source_path = saved.resolve()
        self.source_mtime = self.source_path.stat().st_mtime
        if self.bound_doc and self.bound_db:
            self.bound_db.execute("UPDATE documents SET pdf_path=? WHERE id=?",
                                  (str(self.source_path), self.bound_doc["id"]))
            self.bound_db.commit()
            D.write_document_reference(self.source_path, self.bound_doc)
            self._set_status(f"Saved changes to the official {self._bound_label()} file.")
            return
        self._set_status(f"Saved changes to {self.source_path.name}.")

    def save_as(self):
        if not self._ensure_open() or not self.source_path:
            return
        out, _ = QFileDialog.getSaveFileName(self, "Save PDF Copy", str(self.source_path), "PDF Files (*.pdf)")
        if not out:
            return
        PT.commit_workspace(self.source_path, out)
        if self.bound_doc:
            self._set_status(f"External copy saved: {Path(out).name}. The official {self._bound_label()} file was not duplicated in AURCO.")
        else:
            self._set_status(f"Saved a new PDF copy: {Path(out).name}")
        self.reload_recent()

    def duplicate_file(self):
        if not self._ensure_open():
            return
        dest_dir = PT.PDF_EXPORT_DIR if self.bound_doc else None
        dup = PT.duplicate_file(self._share_pdf() or self._current_pdf(), dest_dir=dest_dir)
        if self.bound_doc:
            self._set_status(f"External duplicate created: {dup.name}. The official {self._bound_label()} file stays as the single source document.")
        else:
            self._set_status(f"Duplicate created: {dup.name}")
        self.reload_recent()

    def rename_file(self):
        if not self._ensure_open() or not self.source_path:
            return
        if self.bound_doc:
            W.error_box(self, f"{self._bound_label()} is controlled by AURCO. Keep the official file name and use Save Copy for any extra file.")
            return
        name, ok = QInputDialog.getText(self, "Rename PDF", "New file name:", text=self.source_path.name)
        if not ok or not name.strip():
            return
        if self.is_dirty():
            self.save_current()
        try:
            newp = PT.rename_file(self.source_path, name.strip())
        except Exception as exc:  # noqa: BLE001
            W.error_box(self, str(exc))
            return
        self.open_file(newp)
        self._set_status(f"Renamed to {newp.name}")

    def undo(self):
        if self.source_path and PT.undo(self.source_path):
            self.reload_document(keep_page=True)
            self._set_status("Undo applied.")

    def redo(self):
        if self.source_path and PT.redo(self.source_path):
            self.reload_document(keep_page=True)
            self._set_status("Redo applied.")

    def open_folder(self):
        if self.source_path:
            D.open_file_location(self.source_path)

    # --------------------------------------------------------- annotate/sign
    def pick_color(self):
        c = QColorDialog.getColor(QColor(self.a_color.text() or "#ffbf00"), self)
        if c.isValid():
            self.a_color.setText(c.name())

    def pick_signature_image(self):
        p, _ = QFileDialog.getOpenFileName(self, "Signature / stamp image", str(Path.home()),
                                           "Images (*.png *.jpg *.jpeg *.bmp)")
        if p:
            self.a_image.setText(p)

    def paste_signature_image(self):
        img = QApplication.clipboard().image()
        if img.isNull() or not self.source_path:
            W.error_box(self, "Copy an image to the clipboard first.")
            return
        out = PT.session_paths(self.source_path)["folder"] / f"signature_{PT._now_tag()}.png"
        if not img.save(str(out), "PNG"):
            W.error_box(self, "The clipboard image could not be saved.")
            return
        self.a_image.setText(str(out))
        self.a_kind.setCurrentText("Signature")
        self._set_status("Signature image pasted from the clipboard.")

    def _annotation_rows(self) -> list[dict]:
        pages = self._picked_range()
        kind = self.a_kind.currentText().lower()
        anns = []
        for i in pages:
            anns.append({
                "page": i + 1,
                "type": kind,
                "text": self.a_text.toPlainText().strip(),
                "x": self.a_x.value(),
                "y": self.a_y.value(),
                "w": self.a_w.value(),
                "h": self.a_h.value(),
                "color": self.a_color.text().strip() or "#ffbf00",
                "image_path": self.a_image.text().strip(),
            })
        return anns

    def apply_annotation(self):
        anns = self._annotation_rows()
        if not anns:
            return
        self._apply_workspace(lambda src, dst: PT.annotate_pdf(src, anns, dst),
                              f"{len(anns)} annotation(s) applied.")

    def save_signed_copy(self):
        anns = self._annotation_rows()
        if not anns:
            return
        if self.bound_doc:
            self._apply_workspace(lambda src, dst: PT.annotate_pdf(src, anns, dst),
                                  f"{len(anns)} annotation(s) applied.")
            self.save_current()
            self._set_status(f"Signature applied to the official {self._bound_label()} PDF. No duplicate document was created.")
            return
        out, _ = QFileDialog.getSaveFileName(self, "Save Signed / Annotated PDF",
                                             str(PT.default_export_path(self.source_path or 'signed', '.signed.pdf')),
                                             "PDF Files (*.pdf)")
        if not out:
            return
        PT.annotate_pdf(self._current_pdf(), anns, out)
        self._set_status(f"Signed / annotated copy saved: {Path(out).name}")

    # ------------------------------------------------------------- organize
    def move_selected_pages(self, delta: int):
        rows = self._selected_rows()
        if not rows:
            return
        if delta < 0:
            for r in rows:
                if r > 0:
                    for c in range(self.page_table.columnCount()):
                        upper = self.page_table.takeItem(r - 1, c)
                        cur = self.page_table.takeItem(r, c)
                        self.page_table.setItem(r - 1, c, cur)
                        self.page_table.setItem(r, c, upper)
            for r in [max(0, r - 1) for r in rows]:
                self.page_table.selectRow(r)
        else:
            for r in reversed(rows):
                if r < self.page_table.rowCount() - 1:
                    for c in range(self.page_table.columnCount()):
                        lower = self.page_table.takeItem(r + 1, c)
                        cur = self.page_table.takeItem(r, c)
                        self.page_table.setItem(r + 1, c, cur)
                        self.page_table.setItem(r, c, lower)
            for r in [min(self.page_table.rowCount() - 1, r + 1) for r in rows]:
                self.page_table.selectRow(r)

    def apply_page_order(self):
        if not self._ensure_open():
            return
        order = [int(self.page_table.item(r, 0).data(Qt.UserRole)) for r in range(self.page_table.rowCount())]
        self._apply_workspace(lambda src, dst: PT.reorder_pdf(src, order, dst), "Page order updated.")

    def duplicate_selected_pages(self):
        pages = self._selected_pages()
        self._apply_workspace(lambda src, dst: PT.duplicate_pages(src, pages, dst),
                              f"{len(pages)} page(s) duplicated.")

    def delete_selected_pages(self):
        pages = self._selected_pages()
        if not W.confirm(self, f"Delete {len(pages)} page(s) from the working copy?"):
            return
        try:
            self._apply_workspace(lambda src, dst: PT.delete_pages(src, pages, dst),
                                  f"{len(pages)} page(s) deleted.")
        except Exception as exc:  # noqa: BLE001
            W.error_box(self, str(exc))

    def extract_selected_pages(self):
        pages = self._selected_pages()
        out, _ = QFileDialog.getSaveFileName(self, "Extract Pages", str(PT.default_export_path(self.source_path or 'extract', '.extract.pdf')),
                                             "PDF Files (*.pdf)")
        if not out:
            return
        PT.extract_pages(self._current_pdf(), pages, out)
        self._set_status(f"Extracted {len(pages)} page(s) to {Path(out).name}")

    def rotate_selected_pages(self, angle: int):
        pages = self._selected_pages()
        self._apply_workspace(lambda src, dst: PT.rotate_pages(src, pages, angle, dst),
                              f"Rotated {len(pages)} page(s) by {angle}°.")

    def merge_pdf(self):
        files, _ = QFileDialog.getOpenFileNames(self, "Select PDF(s) to merge", str(Path.home()), "PDF Files (*.pdf)")
        if not files:
            return
        self._apply_workspace(lambda src, dst: PT.merge_pdfs([src, *files], dst),
                              f"Merged {len(files)} extra PDF file(s).")

    def split_pdf(self):
        if not self._ensure_open():
            return
        ranges, ok = QInputDialog.getText(self, "Split PDF", "Page ranges separated by ;\nExample: 1-2;3;4-5")
        if not ok or not ranges.strip():
            return
        out = QFileDialog.getExistingDirectory(self, "Folder for split PDFs", str(self.source_path.parent))
        if not out:
            return
        pieces = PT.split_pdf(self._current_pdf(), [x.strip() for x in ranges.split(";") if x.strip()], out)
        self._set_status(f"Created {len(pieces)} split PDF file(s).")

    # -------------------------------------------------------------- convert
    def export_images(self, fmt: str):
        if not self._ensure_open() or not self.source_path:
            return
        folder = QFileDialog.getExistingDirectory(self, f"Export {fmt.upper()} pages", str(self.source_path.parent))
        if not folder:
            return
        files = PT.export_all_images(self._current_pdf(), folder, fmt=fmt)
        self._set_status(f"Exported {len(files)} page image(s) to {folder}")

    def export_docx(self):
        if not self._ensure_open() or not self.source_path:
            return
        out, _ = QFileDialog.getSaveFileName(self, "Convert to Word", str(PT.default_export_path(self.source_path, ".docx")),
                                             "Word Files (*.docx)")
        if out:
            PT.convert_to_docx(self._current_pdf(), out)
            self._set_status(f"Word file created: {Path(out).name}")

    def export_xlsx(self):
        if not self._ensure_open() or not self.source_path:
            return
        out, _ = QFileDialog.getSaveFileName(self, "Convert to Excel", str(PT.default_export_path(self.source_path, ".xlsx")),
                                             "Excel Files (*.xlsx)")
        if out:
            PT.convert_to_xlsx(self._current_pdf(), out)
            self._set_status(f"Excel file created: {Path(out).name}")

    def export_txt(self):
        if not self._ensure_open() or not self.source_path:
            return
        out, _ = QFileDialog.getSaveFileName(self, "Export Text", str(PT.default_export_path(self.source_path, ".txt")),
                                             "Text Files (*.txt)")
        if out:
            PT.convert_to_txt(self._current_pdf(), out)
            self._set_status(f"Text export created: {Path(out).name}")

    def export_html(self):
        if not self._ensure_open() or not self.source_path:
            return
        out, _ = QFileDialog.getSaveFileName(self, "Export HTML", str(PT.default_export_path(self.source_path, ".html")),
                                             "HTML Files (*.html)")
        if out:
            PT.convert_to_html(self._current_pdf(), out)
            self._set_status(f"HTML export created: {Path(out).name}")

    # --------------------------------------------------------------- print
    def preview_print_job(self):
        out = self._make_subset()
        if out:
            dlg = PdfViewerDialog(self)
            dlg.open_file(out, title=f"Print Preview — {Path(out).name}")
            printer = self._selected_printer_name() or "system default printer"
            self._set_status(f"Print preview created with {self.p_copies.value()} copy/copies for {printer}.")

    def print_with_options(self):
        pdf = self._make_subset()
        if not pdf:
            return
        db = self._db()
        copies = self.p_copies.value()
        printer = self._selected_printer_name()
        for _ in range(copies):
            D.print_file(db, pdf, printer_name=printer or None)
        self._set_status(
            f"Sent {copies} print job(s) for {pdf.name} to {printer or 'the system default printer'}."
        )

    # -------------------------------------------------------------- security
    def protect_copy(self):
        if not self._ensure_open() or not self.source_path:
            return
        if not self.sec_user.text():
            W.error_box(self, "Enter at least the open password.")
            return
        out, _ = QFileDialog.getSaveFileName(self, "Save Protected PDF",
                                             str(PT.default_export_path(self.source_path, ".protected.pdf")),
                                             "PDF Files (*.pdf)")
        if not out:
            return
        PT.protect_pdf(self._current_pdf(), out, self.sec_user.text(), self.sec_owner.text(),
                       self.sec_print.isChecked(), self.sec_copy.isChecked(), self.sec_modify.isChecked())
        self._set_status(f"Protected PDF saved: {Path(out).name}")

    # ---------------------------------------------------------------- share
    def share_email(self):
        pdf = self._share_pdf()
        db = self._db()
        if not pdf:
            return
        to = self.mail_to.text().strip()
        if not to:
            W.error_box(self, "Enter the recipient email address first.")
            return
        try:
            msg = D.email_pdf(db, pdf, to)
            self._set_status(msg)
        except Exception as exc:  # noqa: BLE001
            W.error_box(self, str(exc))

    def share_whatsapp(self):
        pdf = self._share_pdf()
        db = self._db()
        if pdf:
            D.whatsapp_share(db, pdf, self.wa_to.text().strip())
            self._set_status("WhatsApp opened with the current PDF ready to attach.")

    def copy_file_link(self):
        if self.source_path:
            QApplication.clipboard().setText(self.source_path.resolve().as_uri())
            self._set_status("File link copied.")

    def copy_path(self):
        if self.source_path:
            QApplication.clipboard().setText(str(self.source_path))
            self._set_status("File path copied.")


def show_pdf(path: str | Path, parent=None, title: str = "") -> bool:
    global _VIEWER
    if _VIEWER is None:
        _VIEWER = PdfViewerDialog(parent)
    return _VIEWER.open_file(path, title)


def open_studio(parent=None):
    global _VIEWER
    if _VIEWER is None:
        _VIEWER = PdfViewerDialog(parent)
    _VIEWER.show()
    _VIEWER.raise_()
    _VIEWER.activateWindow()
    return _VIEWER
